package CRUD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.servin.DB_Connection;
import com.servin.User_Bean;

public class Read_Values{
	
	
	public static void main(String [] args) {
		Read_Values obj_Read_Values = new Read_Values();
		obj_Read_Values.get_values();
	}

	
	public List<User_Bean> get_values(){
		DB_Connection DB_obj = new DB_Connection();
		Connection connection = DB_obj.get_Connection();
		
		PreparedStatement ps = null;
		ResultSet rs= null;
		
		List<User_Bean> list= new ArrayList<User_Bean>();
		
		try {
			String querry="select * from mecine_tb";
			ps=connection.prepareStatement(querry);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				
				User_Bean obj_User_Bean = new User_Bean();
				System.out.println(rs.getString("sl_no"));
				System.out.println(rs.getString("medicine"));
				System.out.println(rs.getString("Medidetails"));
				System.out.println(rs.getString("forDecise"));
				
				
				obj_User_Bean.setSl_no(rs.getString("sl_no"));
				obj_User_Bean.setMedidetails(rs.getString("Medidetails"));
				obj_User_Bean.setMedicine(rs.getString("medicine"));
				obj_User_Bean.setForDecise(rs.getString("forDecise"));
				
				
				list.add(obj_User_Bean);
			}
			
		}catch(Exception e) {
			System.out.println(e);
		}
		
		return list;
	}
	
}
