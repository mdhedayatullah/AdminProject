package CRUD;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.servin.DB_Connection;

public class Insert_Values {

	
	public void  insert_values(String sl_no,String medicine,String Medidetails,String forDecise) {
		
		DB_Connection DB_obj = new DB_Connection();
		Connection connection = DB_obj.get_Connection();
		
		PreparedStatement ps = null;
		
		try{
			
		String querry="insert into mecine_tb(sl_no,medicine,Medidetails,forDecise) values(?,?,?,?)";
		ps=connection.prepareStatement(querry);
		ps.setString(1, sl_no);
		ps.setString(2, medicine);
		ps.setString(3, Medidetails);
		ps.setString(4, forDecise);
		
		ps.executeUpdate();
		
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}
}
