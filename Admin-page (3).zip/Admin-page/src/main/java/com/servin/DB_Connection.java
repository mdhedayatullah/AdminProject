package com.servin;

import java.sql.Connection;
import java.sql.DriverManager;

public class DB_Connection {
	
	public static void main(String [] args) {
		DB_Connection DB_obj = new DB_Connection();
		
		System.out.println(DB_obj.get_Connection());
	}

	public Connection get_Connection() {
		
		
		Connection connection = null;
		
		try {

			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/admindb","root","W@2915djkq#");
				
		}catch(Exception e) {
			System.out.println(e);
		}
		return connection;
		
	}
}
