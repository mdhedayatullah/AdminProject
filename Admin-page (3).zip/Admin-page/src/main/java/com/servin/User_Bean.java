package com.servin;

public class User_Bean {

	
	private String sl_no;
	private String  Medidetails;
	private String medicine;
	private String forDecise;
	public String getSl_no() {
		return sl_no;
	}
	public void setSl_no(String sl_no) {
		this.sl_no = sl_no;
	}
	public String getMedidetails() {
		return Medidetails;
	}
	public void setMedidetails(String medidetails) {
		Medidetails = medidetails;
	}
	public String getMedicine() {
		return medicine;
	}
	public void setMedicine(String medicine) {
		this.medicine = medicine;
	}
	public String getForDecise() {
		return forDecise;
	}
	public void setForDecise(String forDecise) {
		this.forDecise = forDecise;
	}
	
	
	
}
