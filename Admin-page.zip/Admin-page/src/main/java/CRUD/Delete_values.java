package CRUD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.servin.DB_Connection;
import com.servin.User_Bean;

public class Delete_values {

	public void delete_value(String sl_no){
		DB_Connection DB_obj = new DB_Connection();
		Connection connection = DB_obj.get_Connection();
		
		PreparedStatement ps = null;
		
		
		try {
			String querry="delete from user where sl_no=?";
			ps=connection.prepareStatement(querry);
			ps.setString(1, sl_no);
			ps.executeUpdate();
			
			
			
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}
	
}
